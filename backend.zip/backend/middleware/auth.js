const jwt = require('jsonwebtoken');
const db = require('../config/db');

const protect = (req, res, next) => {
  let token;
  if (req.headers.authorization && req.headers.authorization.startsWith('Bearer ')) {
    token = req.headers.authorization.split(' ')[1];
  }
  if (!token) return res.status(401).json({ message: 'Not authorized, no token' });

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'vendora_secret');
    const user = db.users.all().find((u) => u._id === decoded.id);
    if (!user) return res.status(401).json({ message: 'User not found' });
    const { password, ...safe } = user;
    req.user = safe;
    next();
  } catch {
    res.status(401).json({ message: 'Not authorized, token failed' });
  }
};

const isVendor = (req, res, next) => {
  if (req.user && (req.user.role === 'vendor' || req.user.role === 'admin')) return next();
  res.status(403).json({ message: 'Access denied: vendors only' });
};

const isAdmin = (req, res, next) => {
  if (req.user && req.user.role === 'admin') return next();
  res.status(403).json({ message: 'Access denied: admins only' });
};

module.exports = { protect, isVendor, isAdmin };

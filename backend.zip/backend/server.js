const express = require('express');
const cors = require('cors');
const dotenv = require('dotenv');
const path = require('path');
const seed = require('./config/seed');

dotenv.config();

const app = express();

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Routes
app.use('/api/auth',       require('./routes/auth'));
app.use('/api/vendors',    require('./routes/vendors'));
app.use('/api/products',   require('./routes/products'));
app.use('/api/orders',     require('./routes/orders'));
app.use('/api/categories', require('./routes/categories'));

app.get('/api/health', (req, res) => res.json({ status: 'OK', message: 'Vendora API running (no-DB mode)' }));

const PORT = process.env.PORT || 5000;

// Always start server, seed runs async
const server = app.listen(PORT, () => {
  console.log(`🚀 Vendora server running on http://localhost:${PORT}/api`);
});

seed().catch((err) => console.error('Seed error:', err));

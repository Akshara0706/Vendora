const fs = require('fs');
const path = require('path');

const dataDir = path.join(__dirname, '..', 'data');

// Ensure data directory exists
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });

const files = {
  users: path.join(dataDir, 'users.json'),
  vendors: path.join(dataDir, 'vendors.json'),
  products: path.join(dataDir, 'products.json'),
  categories: path.join(dataDir, 'categories.json'),
  orders: path.join(dataDir, 'orders.json'),
};

const read = (file) => {
  if (!fs.existsSync(file)) return [];
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); }
  catch { return []; }
};

const write = (file, data) => {
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
};

const genId = () => Math.random().toString(36).slice(2) + Date.now().toString(36);

const db = {
  users:      { all: () => read(files.users),      save: (d) => write(files.users, d) },
  vendors:    { all: () => read(files.vendors),    save: (d) => write(files.vendors, d) },
  products:   { all: () => read(files.products),   save: (d) => write(files.products, d) },
  categories: { all: () => read(files.categories), save: (d) => write(files.categories, d) },
  orders:     { all: () => read(files.orders),     save: (d) => write(files.orders, d) },
  genId,
};

module.exports = db;

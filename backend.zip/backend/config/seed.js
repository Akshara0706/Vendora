const bcrypt = require('bcryptjs');
const db = require('../config/db');

const seed = async () => {
  const existing = db.products.all();
  if (existing.length > 0) return; // already seeded

  console.log('🌱 Seeding sample data...');

  // Categories
  const categories = [
    { _id: 'cat1', name: 'Groceries',      slug: 'groceries',      icon: '🛒', isActive: true },
    { _id: 'cat2', name: 'Stationery',     slug: 'stationery',     icon: '✏️', isActive: true },
    { _id: 'cat3', name: 'Hardware',       slug: 'hardware',       icon: '🔧', isActive: true },
    { _id: 'cat4', name: 'Electrical',     slug: 'electrical',     icon: '⚡', isActive: true },
    { _id: 'cat5', name: 'Office Products',slug: 'office-products',icon: '🖨️', isActive: true },
  ];
  db.categories.save(categories);

  // Users
  const adminPass  = await bcrypt.hash('admin123', 10);
  const vendorPass = await bcrypt.hash('vendor123', 10);
  const custPass   = await bcrypt.hash('customer123', 10);

  const users = [
    { _id: 'user1', name: 'Admin User',     email: 'admin@vendora.com',    password: adminPass,  role: 'admin',    phone: '9000000001', isActive: true, createdAt: new Date().toISOString() },
    { _id: 'user2', name: 'Ravi Kumar',     email: 'ravi@vendor.com',      password: vendorPass, role: 'vendor',   phone: '9000000002', isActive: true, createdAt: new Date().toISOString() },
    { _id: 'user3', name: 'Priya Stores',   email: 'priya@vendor.com',     password: vendorPass, role: 'vendor',   phone: '9000000003', isActive: true, createdAt: new Date().toISOString() },
    { _id: 'user4', name: 'Suresh Electrics',email:'suresh@vendor.com',    password: vendorPass, role: 'vendor',   phone: '9000000004', isActive: true, createdAt: new Date().toISOString() },
    { _id: 'user5', name: 'Anita Sharma',   email: 'anita@customer.com',   password: custPass,   role: 'customer', phone: '9000000005', isActive: true, createdAt: new Date().toISOString() },
  ];
  db.users.save(users);

  // Vendors
  const vendors = [
    {
      _id: 'vendor1', user: 'user2', shopName: "Ravi's Fresh Mart",
      shopDescription: 'Your neighbourhood grocery store with fresh fruits, vegetables and daily essentials.',
      category: 'Groceries', isApproved: true, isActive: true, rating: 4.5, totalReviews: 12,
      address: { street: '12 MG Road', city: 'Bangalore', state: 'Karnataka', pincode: '560001' },
      phone: '9000000002', email: 'ravi@vendor.com',
      deliveryOptions: { pickup: true, delivery: true, deliveryCharge: 30, deliveryRadius: 5, minOrderAmount: 200 },
      createdAt: new Date().toISOString(),
    },
    {
      _id: 'vendor2', user: 'user3', shopName: "Priya Stationery & Office",
      shopDescription: 'Complete range of stationery, art supplies and office products.',
      category: 'Stationery', isApproved: true, isActive: true, rating: 4.2, totalReviews: 8,
      address: { street: '45 Brigade Road', city: 'Bangalore', state: 'Karnataka', pincode: '560025' },
      phone: '9000000003', email: 'priya@vendor.com',
      deliveryOptions: { pickup: true, delivery: true, deliveryCharge: 50, deliveryRadius: 8, minOrderAmount: 300 },
      createdAt: new Date().toISOString(),
    },
    {
      _id: 'vendor3', user: 'user4', shopName: "Suresh Electricals",
      shopDescription: 'All electrical components, wiring accessories and home appliances.',
      category: 'Electrical', isApproved: true, isActive: true, rating: 4.7, totalReviews: 20,
      address: { street: '8 SP Road', city: 'Bangalore', state: 'Karnataka', pincode: '560002' },
      phone: '9000000004', email: 'suresh@vendor.com',
      deliveryOptions: { pickup: true, delivery: false, deliveryCharge: 0, deliveryRadius: 3, minOrderAmount: 0 },
      createdAt: new Date().toISOString(),
    },
  ];
  db.vendors.save(vendors);

  // Products — images use free Unsplash source URLs (no upload needed)
  const now = new Date().toISOString();
  const products = [
    // Groceries - vendor1
    { _id: 'prod1',  vendor: 'vendor1', name: 'Basmati Rice (5kg)',            description: 'Premium aged basmati rice, long grain, aromatic.',          price: 320,  mrp: 380, discount: 15, category: 'cat1', images: ['https://images.unsplash.com/photo-1586201375761-83865001e31c?w=400'], stock: 50,  unit: 'pack',  isActive: true, isFeatured: true,  rating: 4.5, totalReviews: 8,  reviews: [], tags: ['rice','staple'], createdAt: now },
    { _id: 'prod2',  vendor: 'vendor1', name: 'Toor Dal (1kg)',                description: 'Clean, sorted toor dal for everyday cooking.',              price: 110,  mrp: 130, discount: 15, category: 'cat1', images: ['https://images.unsplash.com/photo-1585032226651-759b368d7246?w=400'], stock: 80,  unit: 'kg',    isActive: true, isFeatured: false, rating: 4.2, totalReviews: 5,  reviews: [], tags: ['dal','lentil'], createdAt: now },
    { _id: 'prod3',  vendor: 'vendor1', name: 'Sunflower Oil (1L)',            description: 'Refined sunflower oil, light and healthy.',                 price: 140,  mrp: 160, discount: 12, category: 'cat1', images: ['https://images.unsplash.com/photo-1474979266404-7eaacbcd87c5?w=400'], stock: 40,  unit: 'litre', isActive: true, isFeatured: false, rating: 4.0, totalReviews: 3,  reviews: [], tags: ['oil','cooking'], createdAt: now },
    { _id: 'prod4',  vendor: 'vendor1', name: 'Whole Wheat Atta (5kg)',        description: 'Stone-ground whole wheat flour, high in fibre.',            price: 210,  mrp: 240, discount: 12, category: 'cat1', images: ['https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?w=400'], stock: 35,  unit: 'pack',  isActive: true, isFeatured: true,  rating: 4.3, totalReviews: 6,  reviews: [], tags: ['flour','wheat'], createdAt: now },
    { _id: 'prod5',  vendor: 'vendor1', name: 'Fresh Tomatoes (1kg)',          description: 'Ripe, farm-fresh tomatoes.',                                price: 35,   mrp: 40,  discount: 12, category: 'cat1', images: ['https://images.unsplash.com/photo-1546094096-0df4bcaaa337?w=400'], stock: 30,  unit: 'kg',    isActive: true, isFeatured: false, rating: 4.1, totalReviews: 4,  reviews: [], tags: ['vegetable','fresh'], createdAt: now },
    { _id: 'prod6',  vendor: 'vendor1', name: 'Amul Butter (500g)',            description: 'Pasteurised butter, rich and creamy.',                      price: 260,  mrp: 280, discount: 7,  category: 'cat1', images: ['https://images.unsplash.com/photo-1589985270826-4b7bb135bc9d?w=400'], stock: 20,  unit: 'pack',  isActive: true, isFeatured: false, rating: 4.6, totalReviews: 10, reviews: [], tags: ['dairy','butter'], createdAt: now },
    { _id: 'prod7',  vendor: 'vendor1', name: 'Sugar (1kg)',                   description: 'Fine white refined sugar.',                                 price: 45,   mrp: 50,  discount: 10, category: 'cat1', images: ['https://images.unsplash.com/photo-1516478177764-9fe5bd7e9717?w=400'], stock: 100, unit: 'kg',    isActive: true, isFeatured: false, rating: 4.0, totalReviews: 2,  reviews: [], tags: ['sugar','staple'], createdAt: now },
    { _id: 'prod8',  vendor: 'vendor1', name: 'Tea Powder (250g)',             description: 'Strong CTC tea, perfect for chai lovers.',                  price: 75,   mrp: 85,  discount: 11, category: 'cat1', images: ['https://images.unsplash.com/photo-1556679343-c7306c1976bc?w=400'], stock: 60,  unit: 'pack',  isActive: true, isFeatured: false, rating: 4.4, totalReviews: 7,  reviews: [], tags: ['tea','beverage'], createdAt: now },

    // Stationery - vendor2
    { _id: 'prod9',  vendor: 'vendor2', name: 'Classmate Notebook (200pg)',    description: 'Single line notebook, smooth pages, durable cover.',        price: 65,   mrp: 75,  discount: 13, category: 'cat2', images: ['https://images.unsplash.com/photo-1531346878377-a5be20888e57?w=400'], stock: 200, unit: 'piece', isActive: true, isFeatured: true,  rating: 4.3, totalReviews: 15, reviews: [], tags: ['notebook','writing'], createdAt: now },
    { _id: 'prod10', vendor: 'vendor2', name: 'Reynolds Ball Pen (Pack of 10)',description: 'Smooth writing blue ball pens.',                             price: 55,   mrp: 65,  discount: 15, category: 'cat2', images: ['https://images.unsplash.com/photo-1583485088034-697b5bc54ccd?w=400'], stock: 150, unit: 'pack',  isActive: true, isFeatured: false, rating: 4.5, totalReviews: 20, reviews: [], tags: ['pen','writing'], createdAt: now },
    { _id: 'prod11', vendor: 'vendor2', name: 'Geometry Box',                  description: 'Complete geometry set with compass, protractor and scales.',price: 120,  mrp: 145, discount: 17, category: 'cat2', images: ['https://images.unsplash.com/photo-1596495578065-6e0763fa1178?w=400'], stock: 75,  unit: 'piece', isActive: true, isFeatured: false, rating: 4.1, totalReviews: 9,  reviews: [], tags: ['geometry','math'], createdAt: now },
    { _id: 'prod12', vendor: 'vendor2', name: 'Stapler with Pins',             description: 'Heavy duty stapler with 1000 staple pins included.',        price: 180,  mrp: 210, discount: 14, category: 'cat2', images: ['https://images.unsplash.com/photo-1612521564730-62fc7691cd85?w=400'], stock: 40,  unit: 'piece', isActive: true, isFeatured: false, rating: 4.0, totalReviews: 5,  reviews: [], tags: ['stapler','office'], createdAt: now },
    { _id: 'prod13', vendor: 'vendor2', name: 'Sticky Notes (5 Colors)',       description: 'Pack of 5 colour sticky note pads, 100 sheets each.',       price: 95,   mrp: 110, discount: 13, category: 'cat2', images: ['https://images.unsplash.com/photo-1586281380349-632531db7ed4?w=400'], stock: 90,  unit: 'pack',  isActive: true, isFeatured: true,  rating: 4.4, totalReviews: 11, reviews: [], tags: ['notes','office'], createdAt: now },
    { _id: 'prod14', vendor: 'vendor2', name: 'A4 Printer Paper (500 sheets)', description: '75gsm white A4 paper for laser and inkjet printers.',       price: 310,  mrp: 350, discount: 11, category: 'cat5', images: ['https://images.unsplash.com/photo-1568667256549-094345857637?w=400'], stock: 60,  unit: 'pack',  isActive: true, isFeatured: false, rating: 4.2, totalReviews: 8,  reviews: [], tags: ['paper','printing'], createdAt: now },
    { _id: 'prod15', vendor: 'vendor2', name: 'Whiteboard Marker (4 colors)',  description: 'Non-permanent dry-erase markers, chisel tip.',               price: 140,  mrp: 165, discount: 15, category: 'cat5', images: ['https://images.unsplash.com/photo-1513542789411-b6a5d4f31634?w=400'], stock: 55,  unit: 'pack',  isActive: true, isFeatured: false, rating: 4.3, totalReviews: 6,  reviews: [], tags: ['marker','whiteboard'], createdAt: now },

    // Electrical - vendor3
    { _id: 'prod16', vendor: 'vendor3', name: 'Havells 6A Switch (Pack of 5)', description: 'Modular 6A switches, fire-resistant body.',                price: 220,  mrp: 260, discount: 15, category: 'cat4', images: ['https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=400'], stock: 100, unit: 'pack',  isActive: true, isFeatured: true,  rating: 4.7, totalReviews: 18, reviews: [], tags: ['switch','wiring'], createdAt: now },
    { _id: 'prod17', vendor: 'vendor3', name: 'Philips LED Bulb 9W',           description: 'Energy-saving LED bulb, cool white, 800 lumens.',           price: 85,   mrp: 100, discount: 15, category: 'cat4', images: ['https://images.unsplash.com/photo-1565193566173-7a0ee3dbe261?w=400'], stock: 200, unit: 'piece', isActive: true, isFeatured: true,  rating: 4.8, totalReviews: 25, reviews: [], tags: ['bulb','lighting'], createdAt: now },
    { _id: 'prod18', vendor: 'vendor3', name: '3-Pin Extension Board (2m)',    description: 'ISI marked extension cord with 4 sockets and switch.',      price: 350,  mrp: 420, discount: 16, category: 'cat4', images: ['https://images.unsplash.com/photo-1531297484001-80022131f5a1?w=400'], stock: 45,  unit: 'piece', isActive: true, isFeatured: false, rating: 4.5, totalReviews: 14, reviews: [], tags: ['extension','socket'], createdAt: now },
    { _id: 'prod19', vendor: 'vendor3', name: 'PVC Insulation Tape',           description: 'Electrical insulation tape, 10m roll, black.',              price: 35,   mrp: 45,  discount: 22, category: 'cat4', images: ['https://images.unsplash.com/photo-1504917595217-d4dc5ebe6122?w=400'], stock: 300, unit: 'piece', isActive: true, isFeatured: false, rating: 4.3, totalReviews: 10, reviews: [], tags: ['tape','insulation'], createdAt: now },
    { _id: 'prod20', vendor: 'vendor3', name: 'MCB 32A Single Pole',           description: 'Schneider miniature circuit breaker for home panels.',      price: 480,  mrp: 560, discount: 14, category: 'cat4', images: ['https://images.unsplash.com/photo-1518770660439-4636190af475?w=400'], stock: 30,  unit: 'piece', isActive: true, isFeatured: false, rating: 4.9, totalReviews: 16, reviews: [], tags: ['mcb','circuit'], createdAt: now },
    { _id: 'prod21', vendor: 'vendor3', name: 'Copper Wire 1.5sqmm (90m)',     description: 'FR grade copper wiring cable for internal house wiring.',   price: 1450, mrp:1700, discount: 14, category: 'cat4', images: ['https://images.unsplash.com/photo-1555664424-778a1e5e1b48?w=400'], stock: 15,  unit: 'roll',  isActive: true, isFeatured: false, rating: 4.6, totalReviews: 12, reviews: [], tags: ['wire','copper'], createdAt: now },
    { _id: 'prod22', vendor: 'vendor3', name: 'Ceiling Fan Regulator',         description: 'Electronic step regulator for ceiling fans, 5 speed.',     price: 195,  mrp: 230, discount: 15, category: 'cat4', images: ['https://images.unsplash.com/photo-1565814329452-e1efa11c5b89?w=400'], stock: 50,  unit: 'piece', isActive: true, isFeatured: false, rating: 4.4, totalReviews: 9,  reviews: [], tags: ['fan','regulator'], createdAt: now },
  ];
  db.products.save(products);

  console.log(`✅ Seeded: ${categories.length} categories, ${vendors.length} vendors, ${products.length} products`);
  console.log('');
  console.log('📋 Sample accounts:');
  console.log('   Admin:    admin@vendora.com    / admin123');
  console.log('   Vendor 1: ravi@vendor.com      / vendor123  (Groceries)');
  console.log('   Vendor 2: priya@vendor.com     / vendor123  (Stationery)');
  console.log('   Vendor 3: suresh@vendor.com    / vendor123  (Electrical)');
  console.log('   Customer: anita@customer.com   / customer123');
};

module.exports = seed;

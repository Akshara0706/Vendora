const express = require('express');
const router = express.Router();
const { placeOrder, getMyOrders, getOrderById, getVendorOrders, updateOrderStatus, cancelOrder } = require('../controllers/orderController');
const { protect, isVendor } = require('../middleware/auth');

router.post('/', protect, placeOrder);
router.get('/my', protect, getMyOrders);
router.get('/vendor', protect, isVendor, getVendorOrders);
router.get('/:id', protect, getOrderById);
router.put('/:id/status', protect, isVendor, updateOrderStatus);
router.put('/:id/cancel', protect, cancelOrder);

module.exports = router;

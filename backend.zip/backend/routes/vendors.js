const express = require('express');
const router = express.Router();
const { registerVendor, getVendors, getVendorById, getMyVendor, updateVendor, approveVendor } = require('../controllers/vendorController');
const { protect, isAdmin } = require('../middleware/auth');

router.get('/', getVendors);
router.post('/register', protect, registerVendor);
router.get('/me', protect, getMyVendor);
router.put('/me', protect, updateVendor);
router.get('/:id', getVendorById);
router.put('/:id/approve', protect, isAdmin, approveVendor);

module.exports = router;

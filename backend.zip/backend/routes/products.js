const express = require('express');
const router = express.Router();
const {
  createProduct, getProducts, getProductById, getMyProducts, updateProduct, deleteProduct, addReview,
} = require('../controllers/productController');
const { protect, isVendor } = require('../middleware/auth');
const upload = require('../middleware/upload');

router.get('/', getProducts);
router.post('/', protect, isVendor, upload.array('images', 5), createProduct);
router.get('/mine', protect, isVendor, getMyProducts);
router.get('/:id', getProductById);
router.put('/:id', protect, isVendor, upload.array('images', 5), updateProduct);
router.delete('/:id', protect, isVendor, deleteProduct);
router.post('/:id/reviews', protect, addReview);

module.exports = router;

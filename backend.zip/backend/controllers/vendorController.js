const db = require('../config/db');

// POST /api/vendors/register
const registerVendor = (req, res) => {
  try {
    const vendors = db.vendors.all();
    if (vendors.find((v) => v.user === req.user._id)) {
      return res.status(400).json({ message: 'Vendor profile already exists' });
    }
    const vendor = { _id: db.genId(), user: req.user._id, isApproved: false, isActive: true, rating: 0, totalReviews: 0, createdAt: new Date().toISOString(), ...req.body };
    vendors.push(vendor);
    db.vendors.save(vendors);

    // Update user role
    const users = db.users.all();
    const idx = users.findIndex((u) => u._id === req.user._id);
    if (idx !== -1) { users[idx].role = 'vendor'; db.users.save(users); }

    res.status(201).json(vendor);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// GET /api/vendors
const getVendors = (req, res) => {
  const { category, search } = req.query;
  let vendors = db.vendors.all().filter((v) => v.isApproved && v.isActive);
  if (category) vendors = vendors.filter((v) => v.category === category);
  if (search)   vendors = vendors.filter((v) => v.shopName?.toLowerCase().includes(search.toLowerCase()));
  res.json(vendors);
};

// GET /api/vendors/:id
const getVendorById = (req, res) => {
  const vendor = db.vendors.all().find((v) => v._id === req.params.id);
  if (!vendor) return res.status(404).json({ message: 'Vendor not found' });
  const user = db.users.all().find((u) => u._id === vendor.user);
  res.json({ ...vendor, user: user ? { _id: user._id, name: user.name, email: user.email, phone: user.phone } : null });
};

// GET /api/vendors/me
const getMyVendor = (req, res) => {
  const vendor = db.vendors.all().find((v) => v.user === req.user._id);
  if (!vendor) return res.status(404).json({ message: 'Vendor profile not found' });
  res.json(vendor);
};

// PUT /api/vendors/me
const updateVendor = (req, res) => {
  const vendors = db.vendors.all();
  const idx = vendors.findIndex((v) => v.user === req.user._id);
  if (idx === -1) return res.status(404).json({ message: 'Vendor not found' });
  vendors[idx] = { ...vendors[idx], ...req.body };
  db.vendors.save(vendors);
  res.json(vendors[idx]);
};

// PUT /api/vendors/:id/approve
const approveVendor = (req, res) => {
  const vendors = db.vendors.all();
  const idx = vendors.findIndex((v) => v._id === req.params.id);
  if (idx === -1) return res.status(404).json({ message: 'Vendor not found' });
  vendors[idx].isApproved = true;
  db.vendors.save(vendors);
  res.json({ message: 'Vendor approved', vendor: vendors[idx] });
};

module.exports = { registerVendor, getVendors, getVendorById, getMyVendor, updateVendor, approveVendor };

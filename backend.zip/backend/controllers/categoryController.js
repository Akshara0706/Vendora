const db = require('../config/db');

const createCategory = (req, res) => {
  try {
    const { name, description, icon } = req.body;
    const categories = db.categories.all();
    if (categories.find((c) => c.name === name)) {
      return res.status(400).json({ message: 'Category already exists' });
    }
    const category = { _id: db.genId(), name, slug: name.toLowerCase().replace(/\s+/g, '-'), description, icon, isActive: true, createdAt: new Date().toISOString() };
    categories.push(category);
    db.categories.save(categories);
    res.status(201).json(category);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

const getCategories = (req, res) => {
  res.json(db.categories.all().filter((c) => c.isActive));
};

const updateCategory = (req, res) => {
  const categories = db.categories.all();
  const idx = categories.findIndex((c) => c._id === req.params.id);
  if (idx === -1) return res.status(404).json({ message: 'Category not found' });
  categories[idx] = { ...categories[idx], ...req.body };
  db.categories.save(categories);
  res.json(categories[idx]);
};

const deleteCategory = (req, res) => {
  const categories = db.categories.all().filter((c) => c._id !== req.params.id);
  db.categories.save(categories);
  res.json({ message: 'Category deleted' });
};

module.exports = { createCategory, getCategories, updateCategory, deleteCategory };

const db = require('../config/db');

// POST /api/orders
const placeOrder = (req, res) => {
  try {
    const { vendorId, items, fulfillmentType, deliveryAddress, paymentMethod, customerNote } = req.body;

    const products = db.products.all();
    let totalAmount = 0;
    const orderItems = [];

    for (const item of items) {
      const idx = products.findIndex((p) => p._id === item.productId);
      if (idx === -1) return res.status(404).json({ message: `Product not found: ${item.productId}` });
      if (products[idx].stock < item.quantity) return res.status(400).json({ message: `Insufficient stock for ${products[idx].name}` });

      orderItems.push({
        product: products[idx]._id, name: products[idx].name,
        image: products[idx].images?.[0] || '',
        price: products[idx].price, quantity: item.quantity, unit: products[idx].unit,
      });
      totalAmount += products[idx].price * item.quantity;
      products[idx].stock -= item.quantity;
    }
    db.products.save(products);

    const vendor = db.vendors.all().find((v) => v._id === vendorId);
    const deliveryCharge = fulfillmentType === 'delivery' ? (vendor?.deliveryOptions?.deliveryCharge || 0) : 0;
    const orders = db.orders.all();
    const order = {
      _id: db.genId(),
      orderNumber: `VND-${Date.now()}-${String(orders.length + 1).padStart(4, '0')}`,
      customer: req.user._id,
      vendor: vendorId,
      items: orderItems,
      totalAmount, deliveryCharge,
      grandTotal: totalAmount + deliveryCharge,
      fulfillmentType,
      deliveryAddress: fulfillmentType === 'delivery' ? deliveryAddress : null,
      paymentMethod: paymentMethod || 'cod',
      paymentStatus: 'pending',
      status: 'pending',
      statusHistory: [{ status: 'pending', note: 'Order placed', updatedAt: new Date().toISOString() }],
      customerNote: customerNote || '',
      createdAt: new Date().toISOString(),
    };
    orders.push(order);
    db.orders.save(orders);

    const enriched = { ...order, vendor: vendor || { _id: vendorId } };
    res.status(201).json(enriched);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// GET /api/orders/my
const getMyOrders = (req, res) => {
  const vendors = db.vendors.all();
  const orders = db.orders.all()
    .filter((o) => o.customer === req.user._id)
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
    .map((o) => ({ ...o, vendor: vendors.find((v) => v._id === o.vendor) || { _id: o.vendor } }));
  res.json(orders);
};

// GET /api/orders/:id
const getOrderById = (req, res) => {
  const order = db.orders.all().find((o) => o._id === req.params.id);
  if (!order) return res.status(404).json({ message: 'Order not found' });

  const vendor = db.vendors.all().find((v) => v._id === order.vendor);
  const customer = db.users.all().find((u) => u._id === order.customer);

  const isCustomer = order.customer === req.user._id;
  const isVendorUser = vendor && vendor.user === req.user._id;
  if (!isCustomer && !isVendorUser && req.user.role !== 'admin') {
    return res.status(403).json({ message: 'Access denied' });
  }
  const { password, ...safeCustomer } = customer || {};
  res.json({ ...order, vendor: vendor || null, customer: safeCustomer });
};

// GET /api/orders/vendor
const getVendorOrders = (req, res) => {
  const vendor = db.vendors.all().find((v) => v.user === req.user._id);
  if (!vendor) return res.status(404).json({ message: 'Vendor not found' });

  const { status } = req.query;
  const users = db.users.all();
  let orders = db.orders.all()
    .filter((o) => o.vendor === vendor._id)
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  if (status) orders = orders.filter((o) => o.status === status);

  const enriched = orders.map((o) => {
    const customer = users.find((u) => u._id === o.customer);
    const { password, ...safeCustomer } = customer || {};
    return { ...o, customer: safeCustomer };
  });
  res.json(enriched);
};

// PUT /api/orders/:id/status
const updateOrderStatus = (req, res) => {
  const vendor = db.vendors.all().find((v) => v.user === req.user._id);
  const orders = db.orders.all();
  const idx = orders.findIndex((o) => o._id === req.params.id);
  if (idx === -1) return res.status(404).json({ message: 'Order not found' });

  if (vendor && orders[idx].vendor !== vendor._id && req.user.role !== 'admin') {
    return res.status(403).json({ message: 'Access denied' });
  }
  orders[idx].status = req.body.status;
  orders[idx].statusHistory.push({ status: req.body.status, note: req.body.note || '', updatedAt: new Date().toISOString() });
  db.orders.save(orders);
  res.json({ message: 'Status updated', order: orders[idx] });
};

// PUT /api/orders/:id/cancel
const cancelOrder = (req, res) => {
  const orders = db.orders.all();
  const idx = orders.findIndex((o) => o._id === req.params.id && o.customer === req.user._id);
  if (idx === -1) return res.status(404).json({ message: 'Order not found' });
  if (!['pending', 'confirmed'].includes(orders[idx].status)) {
    return res.status(400).json({ message: 'Cannot cancel at this stage' });
  }
  orders[idx].status = 'cancelled';
  orders[idx].statusHistory.push({ status: 'cancelled', note: 'Cancelled by customer', updatedAt: new Date().toISOString() });

  // Restore stock
  const products = db.products.all();
  orders[idx].items.forEach((item) => {
    const pidx = products.findIndex((p) => p._id === item.product);
    if (pidx !== -1) products[pidx].stock += item.quantity;
  });
  db.products.save(products);
  db.orders.save(orders);
  res.json({ message: 'Order cancelled' });
};

module.exports = { placeOrder, getMyOrders, getOrderById, getVendorOrders, updateOrderStatus, cancelOrder };

const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const db = require('../config/db');

const generateToken = (id) => jwt.sign({ id }, process.env.JWT_SECRET || 'vendora_secret', { expiresIn: '7d' });

// POST /api/auth/register
const register = async (req, res) => {
  try {
    const { name, email, password, role, phone } = req.body;
    const users = db.users.all();
    if (users.find((u) => u.email === email)) {
      return res.status(400).json({ message: 'Email already registered' });
    }
    const hashed = await bcrypt.hash(password, 10);
    const user = {
      _id: db.genId(), name, email, password: hashed,
      role: role || 'customer', phone: phone || '',
      isActive: true, createdAt: new Date().toISOString(),
    };
    users.push(user);
    db.users.save(users);
    res.status(201).json({ _id: user._id, name, email, role: user.role, token: generateToken(user._id) });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// POST /api/auth/login
const login = async (req, res) => {
  try {
    const { email, password } = req.body;
    const users = db.users.all();
    const user = users.find((u) => u.email === email);
    if (!user || !(await bcrypt.compare(password, user.password))) {
      return res.status(401).json({ message: 'Invalid email or password' });
    }
    if (!user.isActive) return res.status(403).json({ message: 'Account deactivated' });

    let vendorId = null;
    if (user.role === 'vendor') {
      const vendor = db.vendors.all().find((v) => v.user === user._id);
      vendorId = vendor ? vendor._id : null;
    }
    res.json({ _id: user._id, name: user.name, email: user.email, role: user.role, vendorId, token: generateToken(user._id) });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// GET /api/auth/profile
const getProfile = (req, res) => {
  const user = db.users.all().find((u) => u._id === req.user._id);
  if (!user) return res.status(404).json({ message: 'User not found' });
  const { password, ...safe } = user;
  res.json(safe);
};

// PUT /api/auth/profile
const updateProfile = async (req, res) => {
  try {
    const users = db.users.all();
    const idx = users.findIndex((u) => u._id === req.user._id);
    if (idx === -1) return res.status(404).json({ message: 'User not found' });
    if (req.body.name)  users[idx].name  = req.body.name;
    if (req.body.phone) users[idx].phone = req.body.phone;
    if (req.body.password) users[idx].password = await bcrypt.hash(req.body.password, 10);
    db.users.save(users);
    const { password, ...safe } = users[idx];
    res.json(safe);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

module.exports = { register, login, getProfile, updateProfile };

const db = require('../config/db');

// POST /api/products
const createProduct = (req, res) => {
  try {
    const vendor = db.vendors.all().find((v) => v.user === req.user._id);
    if (!vendor) return res.status(403).json({ message: 'Vendor profile not found' });
    if (!vendor.isApproved) return res.status(403).json({ message: 'Vendor account pending approval' });

    const images = req.files ? req.files.map((f) => `/uploads/${f.filename}`) : [];
    const product = {
      _id: db.genId(), vendor: vendor._id, isActive: true, isFeatured: false,
      rating: 0, totalReviews: 0, reviews: [], createdAt: new Date().toISOString(),
      ...req.body,
      price: Number(req.body.price), stock: Number(req.body.stock),
      discount: Number(req.body.discount || 0), images,
    };
    const products = db.products.all();
    products.unshift(product);
    db.products.save(products);
    res.status(201).json(product);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// GET /api/products
const getProducts = (req, res) => {
  const { category, vendor, search, minPrice, maxPrice, page = 1, limit = 12 } = req.query;
  let products = db.products.all().filter((p) => p.isActive);

  if (category) products = products.filter((p) => p.category === category);
  if (vendor)   products = products.filter((p) => p.vendor === vendor);
  if (search)   products = products.filter((p) => p.name?.toLowerCase().includes(search.toLowerCase()));
  if (minPrice) products = products.filter((p) => p.price >= Number(minPrice));
  if (maxPrice) products = products.filter((p) => p.price <= Number(maxPrice));

  const total = products.length;
  const skip  = (Number(page) - 1) * Number(limit);
  const paged = products.slice(skip, skip + Number(limit));

  // Enrich with vendor and category info
  const vendors    = db.vendors.all();
  const categories = db.categories.all();
  const enriched = paged.map((p) => ({
    ...p,
    vendor:   vendors.find((v) => v._id === p.vendor)    || { _id: p.vendor },
    category: categories.find((c) => c._id === p.category) || { _id: p.category },
  }));

  res.json({ products: enriched, total, page: Number(page), pages: Math.ceil(total / Number(limit)) });
};

// GET /api/products/:id
const getProductById = (req, res) => {
  const product = db.products.all().find((p) => p._id === req.params.id);
  if (!product) return res.status(404).json({ message: 'Product not found' });

  const vendor   = db.vendors.all().find((v) => v._id === product.vendor);
  const category = db.categories.all().find((c) => c._id === product.category);
  res.json({ ...product, vendor: vendor || null, category: category || null });
};

// GET /api/products/mine
const getMyProducts = (req, res) => {
  const vendor = db.vendors.all().find((v) => v.user === req.user._id);
  if (!vendor) return res.status(404).json({ message: 'Vendor not found' });
  const categories = db.categories.all();
  const products = db.products.all()
    .filter((p) => p.vendor === vendor._id)
    .map((p) => ({ ...p, category: categories.find((c) => c._id === p.category) || { _id: p.category } }));
  res.json(products);
};

// PUT /api/products/:id
const updateProduct = (req, res) => {
  const vendor = db.vendors.all().find((v) => v.user === req.user._id);
  const products = db.products.all();
  const idx = products.findIndex((p) => p._id === req.params.id && p.vendor === vendor?._id);
  if (idx === -1) return res.status(404).json({ message: 'Product not found or unauthorized' });

  const images = req.files?.length ? req.files.map((f) => `/uploads/${f.filename}`) : products[idx].images;
  products[idx] = { ...products[idx], ...req.body, images };
  if (req.body.price) products[idx].price = Number(req.body.price);
  if (req.body.stock) products[idx].stock = Number(req.body.stock);
  db.products.save(products);
  res.json(products[idx]);
};

// DELETE /api/products/:id
const deleteProduct = (req, res) => {
  const vendor = db.vendors.all().find((v) => v.user === req.user._id);
  const products = db.products.all();
  const idx = products.findIndex((p) => p._id === req.params.id && p.vendor === vendor?._id);
  if (idx === -1) return res.status(404).json({ message: 'Product not found or unauthorized' });
  products.splice(idx, 1);
  db.products.save(products);
  res.json({ message: 'Product deleted' });
};

// POST /api/products/:id/reviews
const addReview = (req, res) => {
  const products = db.products.all();
  const idx = products.findIndex((p) => p._id === req.params.id);
  if (idx === -1) return res.status(404).json({ message: 'Product not found' });

  const already = products[idx].reviews?.find((r) => r.user === req.user._id);
  if (already) return res.status(400).json({ message: 'Already reviewed' });

  const review = { user: req.user._id, name: req.user.name, rating: Number(req.body.rating), comment: req.body.comment, createdAt: new Date().toISOString() };
  products[idx].reviews = products[idx].reviews || [];
  products[idx].reviews.push(review);
  products[idx].totalReviews = products[idx].reviews.length;
  products[idx].rating = products[idx].reviews.reduce((s, r) => s + r.rating, 0) / products[idx].reviews.length;
  db.products.save(products);
  res.status(201).json({ message: 'Review added' });
};

module.exports = { createProduct, getProducts, getProductById, getMyProducts, updateProduct, deleteProduct, addReview };

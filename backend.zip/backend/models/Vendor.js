const mongoose = require('mongoose');

const vendorSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    shopName: { type: String, required: true, trim: true },
    shopDescription: { type: String, trim: true },
    logo: { type: String },
    banner: { type: String },
    category: { type: String, enum: ['Groceries', 'Stationery', 'Hardware', 'Electrical', 'Office Products', 'Other'], required: true },
    address: {
      street: { type: String, required: true },
      city: { type: String, required: true },
      state: { type: String, required: true },
      pincode: { type: String, required: true },
    },
    phone: { type: String },
    email: { type: String },
    isApproved: { type: Boolean, default: false },
    isActive: { type: Boolean, default: true },
    deliveryOptions: {
      pickup: { type: Boolean, default: true },
      delivery: { type: Boolean, default: false },
      deliveryRadius: { type: Number, default: 5 }, // in km
      minOrderAmount: { type: Number, default: 0 },
      deliveryCharge: { type: Number, default: 0 },
    },
    rating: { type: Number, default: 0 },
    totalReviews: { type: Number, default: 0 },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Vendor', vendorSchema);
